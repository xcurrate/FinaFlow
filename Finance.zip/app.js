// ================= CONFIG =================
const SUPABASE_URL = "PASTE_SUPABASE_URL";
const SUPABASE_ANON_KEY = "PASTE_SUPABASE_ANON_KEY";

const supabase = supabaseJs.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentUser = null;
let chart = null;

// ================= AUTH =================
async function register() {
  const email = email.value;
  const password = password.value;

  await supabase.auth.signUp({ email, password });
}

async function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const { data } = await supabase.auth.signInWithPassword({ email, password });
  currentUser = data.user;
  initApp();
}

async function logout() {
  await supabase.auth.signOut();
  location.reload();
}

// ================= INIT =================
async function initApp() {
  document.getElementById("auth-section").classList.add("hidden");
  document.getElementById("app-section").classList.remove("hidden");

  loadTransactions("month");
}

// ================= CRUD =================
async function addTransaction() {
  const amount = Number(document.getElementById("amount").value);
  const category = document.getElementById("category").value;
  const date = document.getElementById("date").value;
  const type = document.getElementById("type").value;

  await supabase.from("transactions").insert({
    user_id: currentUser.id,
    amount,
    category,
    date,
    type
  });

  loadTransactions("month");
}

async function deleteTransaction(id) {
  await supabase.from("transactions").delete().eq("id", id);
  loadTransactions("month");
}

// ================= LOAD DATA =================
async function loadTransactions(filter) {
  const start = new Date();
  if (filter === "day") start.setDate(start.getDate() - 1);
  if (filter === "week") start.setDate(start.getDate() - 7);
  if (filter === "month") start.setMonth(start.getMonth() - 1);

  const { data } = await supabase
    .from("transactions")
    .select("*")
    .eq("user_id", currentUser.id)
    .gte("date", start.toISOString().split("T")[0]);

  renderTable(data);
  renderSummary(data);
  renderChart(data);
  renderAdvice(data);
}

// ================= RENDER =================
function renderTable(data) {
  const tbody = document.querySelector("#transaction-table tbody");
  tbody.innerHTML = "";

  data.forEach(t => {
    tbody.innerHTML += `
      <tr>
        <td>${t.date}</td>
        <td>${t.category}</td>
        <td>${t.type}</td>
        <td>Rp ${t.amount.toLocaleString()}</td>
        <td><button class="danger" onclick="deleteTransaction(${t.id})">X</button></td>
      </tr>
    `;
  });
}

function renderSummary(data) {
  let income = 0;
  let expense = 0;

  data.forEach(t => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  document.getElementById("saldo").innerText = `Rp ${(income - expense).toLocaleString()}`;
  document.getElementById("total-income").innerText = `Rp ${income.toLocaleString()}`;
  document.getElementById("total-expense").innerText = `Rp ${expense.toLocaleString()}`;
}

function renderChart(data) {
  let income = 0;
  let expense = 0;

  data.forEach(t => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  if (chart) chart.destroy();

  chart = new Chart(document.getElementById("financeChart"), {
    type: "doughnut",
    data: {
      labels: ["Income", "Expense"],
      datasets: [{
        data: [income, expense],
        backgroundColor: ["#16a34a", "#dc2626"]
      }]
    }
  });
}

function renderAdvice(data) {
  let income = 0;
  let expense = 0;

  data.forEach(t => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  const card = document.getElementById("advice-card");
  card.className = "advice";

  if (expense > income * 0.8) {
    card.classList.add("red");
    card.innerText = "Pengeluaran terlalu tinggi. Kontrol keuangan segera.";
  } else if (expense < income * 0.5) {
    card.classList.add("green");
    card.innerText = "Keuangan sehat. Pertahankan disiplin.";
  } else {
    card.innerText = "";
  }
}