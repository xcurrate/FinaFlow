// ================= CONFIG =================
// ⚠️ MASUKKAN URL & KEY SUPABASE ANDA DI SINI
const SUPABASE_URL = "https://sbxtfqidotarniglzban.supabase.co"; 
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNieHRmcWlkb3Rhcm5pZ2x6YmFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyMjgxODQsImV4cCI6MjA4MzgwNDE4NH0.MCiWNCcmQRBmAvAbsbcpdMbSOWAg7zPqJynpCLf1RKQ";

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
let currentUser = null;
let expenseChart = null;

// Kategori
const categories = {
    income: ["Gaji", "Bonus", "Bisnis", "Lainnya"],
    expense: ["Belanja", "Makan", "Transport", "Tagihan", "Hiburan", "Kesehatan", "Lainnya"]
};

// ================= INIT =================
window.addEventListener('DOMContentLoaded', async () => {
    feather.replace(); // Load Icons
    updateCategories();
    
    // Default Date
    document.getElementById("date").valueAsDate = new Date();
    document.getElementById("current-date").innerText = new Date().toLocaleDateString('id-ID', { dateStyle: 'full' });
    
    // Default Filter
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    document.getElementById("filter-start").valueAsDate = firstDay;
    document.getElementById("filter-end").valueAsDate = today;

    // Check Auth
    const { data: { session } } = await sb.auth.getSession();
    if (session) {
        currentUser = session.user;
        initApp();
    }
});

// ================= UI NAVIGATION =================
function toggleSidebar() {
    document.getElementById("sidebar").classList.add("active");
    document.getElementById("overlay").classList.add("active");
}
function closeSidebar() {
    document.getElementById("sidebar").classList.remove("active");
    document.getElementById("overlay").classList.remove("active");
}
function switchTab(tab) {
    document.querySelectorAll(".tab-content").forEach(el => el.classList.add("hidden"));
    document.getElementById(`view-${tab}`).classList.remove("hidden");
    closeSidebar();
}

function initApp() {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("app-section").classList.remove("hidden");
    document.getElementById("user-display").innerText = currentUser.email;
    loadTransactions('custom');
    loadPlans();
}

// ================= LOGIKA RENCANA -> REALISASI =================
async function addPlan() {
    const item = document.getElementById("plan-item").value;
    const amount = document.getElementById("plan-amount").value || 0;
    
    if(!item) return alert("Nama barang wajib diisi!");

    await sb.from("shopping_list").insert({
        user_id: currentUser.id,
        item_name: item,
        amount: amount,
        is_bought: false
    });

    document.getElementById("plan-item").value = "";
    document.getElementById("plan-amount").value = "";
    loadPlans();
}

async function loadPlans() {
    const { data } = await sb.from("shopping_list")
        .select("*")
        .eq("user_id", currentUser.id)
        .order("is_bought", {ascending: true}) // Yang belum beli di atas
        .order("created_at", {ascending: false});

    const container = document.getElementById("planning-list");
    container.innerHTML = "";

    if(!data || data.length === 0) {
        container.innerHTML = "<p class='text-muted' style='text-align:center'>Belum ada rencana.</p>";
        return;
    }

    data.forEach(p => {
        const iconCheck = p.is_bought ? "check-square" : "square";
        const doneClass = p.is_bought ? "checked" : "";
        const rowClass = p.is_bought ? "done" : "";

        container.innerHTML += `
            <div class="plan-item ${rowClass}">
                <div class="checkbox-wrapper" onclick="realizePlan(${p.id}, ${!p.is_bought}, '${p.item_name}', ${p.amount})">
                    <div class="custom-checkbox ${doneClass}">
                        <i data-feather="${p.is_bought ? 'check' : ''}" style="width:14px"></i>
                    </div>
                    <div>
                        <div style="font-weight:600">${p.item_name}</div>
                        <small class="text-muted">Est: Rp ${Number(p.amount).toLocaleString()}</small>
                    </div>
                </div>
                <button class="btn-icon danger" onclick="deletePlan(${p.id})"><i data-feather="trash-2"></i></button>
            </div>
        `;
    });
    feather.replace();
}

// 🔥 FUNGSI SAKTI: PINDAHKAN RENCANA KE PENGELUARAN
async function realizePlan(id, newStatus, name, amount) {
    if(newStatus === true) {
        // Jika dicentang (Realisasi)
        const confirmBuy = confirm(`Barang "${name}" sudah dibeli? \nKlik OK untuk mencatatnya otomatis ke Daftar Pengeluaran.`);
        
        if(confirmBuy) {
            // 1. Masukkan ke Transaksi (Pengeluaran)
            const { error } = await sb.from("transactions").insert({
                user_id: currentUser.id,
                type: 'expense',
                category: 'Belanja', // Default kategori
                description: `[Realisasi] ${name}`,
                amount: amount,
                date: new Date().toISOString().split('T')[0]
            });

            if(!error) {
                // 2. Update status rencana jadi is_bought = true
                await sb.from("shopping_list").update({ is_bought: true }).eq("id", id);
                alert("Berhasil dicatat ke pengeluaran!");
            }
        }
    } else {
        // Jika uncheck (Batal beli), kembalikan status saja
        await sb.from("shopping_list").update({ is_bought: false }).eq("id", id);
    }
    
    loadPlans();
    loadTransactions('custom'); // Refresh dashboard juga
}

async function deletePlan(id) {
    if(confirm("Hapus rencana ini?")) {
        await sb.from("shopping_list").delete().eq("id", id);
        loadPlans();
    }
}

// ================= CRUD TRANSAKSI & CHART =================
async function addTransaction() {
    const type = document.getElementById("type").value;
    const category = document.getElementById("category").value;
    const amount = Number(document.getElementById("amount").value);
    const date = document.getElementById("date").value;
    const desc = document.getElementById("desc").value || "-";

    if(!amount) return alert("Nominal wajib diisi!");

    await sb.from("transactions").insert({ user_id: currentUser.id, type, category, amount, date, description: desc });
    
    document.getElementById("amount").value = "";
    document.getElementById("desc").value = "";
    loadTransactions('custom');
}

async function loadTransactions(mode) {
    let query = sb.from("transactions").select("*").eq("user_id", currentUser.id).order("date", {ascending: false});

    if(mode === 'custom') {
        const s = document.getElementById("filter-start").value;
        const e = document.getElementById("filter-end").value;
        if(s) query = query.gte("date", s);
        if(e) query = query.lte("date", e);
    }

    const { data } = await query;
    renderDashboard(data);
}

function renderDashboard(data) {
    const tbody = document.querySelector("#transaction-table tbody");
    const printTbody = document.getElementById("print-table");
    
    tbody.innerHTML = "";
    // Header tabel print
    printTbody.innerHTML = `<thead>
        <tr style="border-bottom:1px solid #000">
            <th style="text-align:left">Tanggal</th>
            <th style="text-align:left">Keterangan</th>
            <th style="text-align:right">Nominal</th>
        </tr>
    </thead><tbody></tbody>`;
    
    let inc = 0, exp = 0;
    let catData = {};

    data.forEach(t => {
        if(t.type === 'income') inc += t.amount;
        else {
            exp += t.amount;
            catData[t.category] = (catData[t.category] || 0) + t.amount;
        }

        const dateStr = t.date.slice(5);
        const colorClass = t.type === 'income' ? 'text-success' : 'text-danger';
        const icon = t.type === 'income' ? 'arrow-up-right' : 'arrow-down-right';

        // Tampilan Web
        tbody.innerHTML += `
            <tr>
                <td>${dateStr}</td>
                <td>
                    <div style="font-weight:600">${t.category}</div>
                    <small class="text-muted">${t.description}</small>
                </td>
                <td style="color:${t.type==='income'?'var(--success)':'var(--danger)'}">
                    Rp ${t.amount.toLocaleString()}
                </td>
                <td><button class="btn-icon danger" onclick="delTrans(${t.id})"><i data-feather="x"></i></button></td>
            </tr>
        `;
        
        // Tampilan Print (Sederhana)
        printTbody.querySelector('tbody').innerHTML += `
            <tr>
                <td>${t.date}</td>
                <td>${t.description} (${t.category})</td>
                <td style="text-align:right">Rp ${t.amount.toLocaleString()}</td>
            </tr>
        `;
    });
    
    feather.replace(); // Refresh icons

    // Update Kartu
    document.getElementById("saldo").innerText = "Rp " + (inc - exp).toLocaleString();
    document.getElementById("total-income").innerText = "Rp " + inc.toLocaleString();
    document.getElementById("total-expense").innerText = "Rp " + exp.toLocaleString();

    // Chart
    const ctx = document.getElementById("expenseChart").getContext('2d');
    if(expenseChart) expenseChart.destroy();
    
    // Warna chart ala Neon
    const colors = ['#3b82f6', '#8b5cf6', '#ef4444', '#10b981', '#f59e0b', '#ec4899'];
    
    expenseChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(catData),
            datasets: [{
                data: Object.values(catData),
                backgroundColor: colors,
                borderColor: '#1e293b',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { color: '#94a3b8' } }
            }
        }
    });
}

// EXPORT JPG
function exportJPG() {
    window.scrollTo(0,0);
    const element = document.getElementById("export-area");
    html2canvas(element, { 
        backgroundColor: "#1e293b", // Pastikan background gelap ter-capture
        scale: 2 
    }).then(canvas => {
        const link = document.createElement('a');
        link.download = `FinaFlow-Report-${Date.now()}.jpg`;
        link.href = canvas.toDataURL("image/jpeg", 0.9);
        link.click();
    });
}

// UTILS
async function delTrans(id) {
    if(confirm("Hapus transaksi?")) {
        await sb.from("transactions").delete().eq("id", id);
        loadTransactions('custom');
    }
}
function updateCategories() {
    const t = document.getElementById("type").value;
    const s = document.getElementById("category"); s.innerHTML = "";
    categories[t].forEach(c => s.innerHTML += `<option>${c}</option>`);
}

// AUTH
async function login() {
    const e = document.getElementById("email").value;
    const p = document.getElementById("password").value;
    const { data, error } = await sb.auth.signInWithPassword({ email: e, password: p });
    if(error) alert(error.message); else { currentUser = data.user; initApp(); }
}
async function register() {
    const e = document.getElementById("email").value;
    const p = document.getElementById("password").value;
    const { error } = await sb.auth.signUp({ email: e, password: p });
    if(error) alert(error.message); else alert("Cek Email!");
}
async function logout() { await sb.auth.signOut(); location.reload(); }